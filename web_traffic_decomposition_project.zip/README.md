
# Website Daily Traffic Decomposition

## How to Run
pip install -r requirements.txt
python traffic_decomposition.py

## Files
- traffic_decomposition.py
- web_traffic.csv
